#!/usr/bin/env python3
"""
Quick start script for the Medical AI Flask server
"""

import os
import sys
import subprocess
from pathlib import Path

def check_dependencies():
    """Check if all required packages are installed"""
    required_packages = [
        'flask', 'tensorflow', 'pillow', 'numpy', 
        'requests', 'web3', 'firebase-admin', 
        'flask-cors', 'python-dotenv', 'gunicorn'
    ]
    
    missing_packages = []
    
    for package in required_packages:
        try:
            __import__(package.replace('-', '_'))
        except ImportError:
            missing_packages.append(package)
    
    if missing_packages:
        print("❌ Missing required packages:")
        for package in missing_packages:
            print(f"   - {package}")
        print("\nInstall missing packages with:")
        print("pip install " + " ".join(missing_packages))
        return False
    
    print("✅ All required packages are installed")
    return True

def check_model_file():
    """Check if the model file exists"""
    model_path = "../attached_assets/hybrid_model_keras3_1758476680787.keras"
    
    if not os.path.exists(model_path):
        print(f"❌ Model file not found: {model_path}")
        print("Please ensure your .keras model file is in the attached_assets directory")
        return False
    
    file_size = os.path.getsize(model_path)
    print(f"✅ Model file found: {model_path}")
    print(f"   File size: {file_size / (1024*1024):.2f} MB")
    return True

def setup_environment():
    """Setup environment variables"""
    env_file = ".env"
    
    if not os.path.exists(env_file):
        print("📝 Creating .env file from template...")
        try:
            # Copy .env.example to .env
            import shutil
            shutil.copy(".env.example", ".env")
            print("✅ Created .env file")
            print("   Please edit .env file to add your API keys and configuration")
        except Exception as e:
            print(f"❌ Failed to create .env file: {str(e)}")
            return False
    else:
        print("✅ .env file exists")
    
    return True

def run_tests():
    """Run the model tests"""
    print("\n🧪 Running model tests...")
    try:
        result = subprocess.run([sys.executable, "test_model.py"], 
                              capture_output=True, text=True, timeout=120)
        
        if result.returncode == 0:
            print("✅ All tests passed!")
            return True
        else:
            print("❌ Some tests failed:")
            print(result.stdout)
            print(result.stderr)
            return False
    except subprocess.TimeoutExpired:
        print("⏰ Tests timed out (this is normal for large models)")
        return True  # Continue anyway
    except Exception as e:
        print(f"❌ Failed to run tests: {str(e)}")
        return False

def start_server(mode='development'):
    """Start the Flask server"""
    print(f"\n🚀 Starting Flask server in {mode} mode...")
    
    if mode == 'development':
        # Run with Flask development server
        os.environ['FLASK_ENV'] = 'development'
        os.environ['DEBUG'] = 'True'
        
        try:
            from app import app
            app.run(host='0.0.0.0', port=5000, debug=True)
        except ImportError as e:
            print(f"❌ Failed to import app: {str(e)}")
            return False
    
    elif mode == 'production':
        # Run with Gunicorn
        try:
            cmd = [
                "gunicorn",
                "--bind", "0.0.0.0:5000",
                "--workers", "2",
                "--timeout", "120",
                "--worker-class", "sync",
                "app:app"
            ]
            
            subprocess.run(cmd)
        except Exception as e:
            print(f"❌ Failed to start Gunicorn: {str(e)}")
            return False
    
    return True

def main():
    """Main function to setup and start the server"""
    print("=" * 60)
    print("🏥 MEDICAL AI SERVER - ALZHEIMER'S PREDICTION")
    print("=" * 60)
    
    print("\n1. Checking dependencies...")
    if not check_dependencies():
        sys.exit(1)
    
    print("\n2. Checking model file...")
    if not check_model_file():
        sys.exit(1)
    
    print("\n3. Setting up environment...")
    if not setup_environment():
        sys.exit(1)
    
    # Ask user if they want to run tests
    run_tests_choice = input("\n4. Run model tests? (y/n): ").lower().strip()
    if run_tests_choice in ['y', 'yes']:
        if not run_tests():
            continue_anyway = input("\nContinue anyway? (y/n): ").lower().strip()
            if continue_anyway not in ['y', 'yes']:
                sys.exit(1)
    
    # Ask for server mode
    print("\n5. Choose server mode:")
    print("   1. Development (Flask dev server)")
    print("   2. Production (Gunicorn)")
    
    mode_choice = input("Enter choice (1-2): ").strip()
    
    if mode_choice == "1":
        mode = "development"
    elif mode_choice == "2":
        mode = "production"
    else:
        print("Invalid choice. Using development mode.")
        mode = "development"
    
    # Final check
    print(f"\n✅ Ready to start server in {mode} mode!")
    print("📋 Server will be available at: http://localhost:5000")
    print("🔗 Health check endpoint: http://localhost:5000/health")
    print("🧠 Prediction endpoint: http://localhost:5000/predict")
    
    input("\nPress Enter to start the server...")
    
    try:
        start_server(mode)
    except KeyboardInterrupt:
        print("\n\n👋 Server stopped by user")
        sys.exit(0)
    except Exception as e:
        print(f"\n❌ Server failed: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    main()