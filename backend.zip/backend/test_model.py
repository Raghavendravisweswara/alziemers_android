#!/usr/bin/env python3
"""
Test script to validate model loading and basic functionality
Run this before starting the main application
"""

import sys
import os
import numpy as np
from PIL import Image
import logging

# Add backend to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from model_loader import ModelLoader
from utils import preprocess_image, validate_image

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def test_model_loading():
    """Test if the Keras model can be loaded successfully"""
    print("=" * 60)
    print("🧠 TESTING ALZHEIMER'S PREDICTION MODEL")
    print("=" * 60)
    
    try:
        # Initialize model loader
        model_loader = ModelLoader()
        
        # Test model loading
        print("\n1. Testing model loading...")
        model_path = "../attached_assets/hybrid_model_keras3_1758476680787.keras"
        
        if not os.path.exists(model_path):
            print(f"❌ Model file not found: {model_path}")
            return False
        
        print(f"📁 Model file found: {model_path}")
        print(f"📊 Model file size: {os.path.getsize(model_path) / (1024*1024):.2f} MB")
        
        # Load the model
        model = model_loader.load_model(model_path)
        
        if model is None:
            print("❌ Model loading failed")
            return False
        
        print("✅ Model loaded successfully!")
        
        # Get model information
        print("\n2. Model Information:")
        print(f"   Input shape: {model.input_shape}")
        print(f"   Output shape: {model.output_shape}")
        
        if hasattr(model, 'count_params'):
            print(f"   Total parameters: {model.count_params():,}")
        
        return True
        
    except Exception as e:
        print(f"❌ Model loading test failed: {str(e)}")
        return False

def test_image_processing():
    """Test image preprocessing pipeline"""
    print("\n3. Testing image preprocessing...")
    
    try:
        # Create a dummy MRI-like image for testing
        dummy_image = Image.new('RGB', (256, 256), color='gray')
        
        # Test image validation
        if not validate_image(dummy_image):
            print("❌ Image validation failed")
            return False
        
        print("✅ Image validation passed")
        
        # Test image preprocessing
        processed = preprocess_image(dummy_image, target_size=(224, 224))
        
        print(f"✅ Image preprocessing successful")
        print(f"   Processed shape: {processed.shape}")
        print(f"   Data type: {processed.dtype}")
        print(f"   Value range: [{processed.min():.3f}, {processed.max():.3f}]")
        
        return True
        
    except Exception as e:
        print(f"❌ Image processing test failed: {str(e)}")
        return False

def test_model_inference():
    """Test model prediction with dummy data"""
    print("\n4. Testing model inference...")
    
    try:
        # Load model
        model_loader = ModelLoader()
        model_path = "../attached_assets/hybrid_model_keras3_1758476680787.keras"
        model = model_loader.load_model(model_path)
        
        # Create dummy input matching model requirements
        input_shape = model.input_shape
        if input_shape[0] is None:  # Batch dimension
            test_shape = (1,) + input_shape[1:]
        else:
            test_shape = input_shape
        
        dummy_input = np.random.random(test_shape).astype(np.float32)
        
        # Make prediction
        prediction = model.predict(dummy_input, verbose=0)
        
        print("✅ Model inference successful!")
        print(f"   Input shape: {dummy_input.shape}")
        print(f"   Output shape: {prediction.shape}")
        print(f"   Prediction probabilities: {prediction[0]}")
        
        # Test prediction interpretation
        predicted_class = np.argmax(prediction, axis=1)[0]
        confidence = prediction[0][predicted_class]
        
        stages = ['Non-Demented', 'Very Mild Dementia', 'Mild Dementia', 'Moderate Dementia']
        print(f"   Predicted stage: {stages[predicted_class]}")
        print(f"   Confidence: {confidence:.3f}")
        
        return True
        
    except Exception as e:
        print(f"❌ Model inference test failed: {str(e)}")
        return False

def test_tflite_conversion():
    """Test TensorFlow Lite conversion for mobile deployment"""
    print("\n5. Testing TensorFlow Lite conversion...")
    
    try:
        # Load model
        model_loader = ModelLoader()
        model_path = "../attached_assets/hybrid_model_keras3_1758476680787.keras"
        model = model_loader.load_model(model_path)
        
        # Convert to TFLite
        tflite_path = model_loader.convert_to_tflite("test_model_mobile.tflite")
        
        if os.path.exists(tflite_path):
            file_size = os.path.getsize(tflite_path)
            print(f"✅ TFLite conversion successful!")
            print(f"   TFLite model saved: {tflite_path}")
            print(f"   TFLite model size: {file_size / 1024:.2f} KB")
            
            # Clean up test file
            os.remove(tflite_path)
            return True
        else:
            print("❌ TFLite file not created")
            return False
        
    except Exception as e:
        print(f"❌ TFLite conversion test failed: {str(e)}")
        return False

def main():
    """Run all tests"""
    print("🚀 Starting Medical AI System Tests\n")
    
    tests = [
        ("Model Loading", test_model_loading),
        ("Image Processing", test_image_processing), 
        ("Model Inference", test_model_inference),
        ("TFLite Conversion", test_tflite_conversion)
    ]
    
    results = {}
    
    for test_name, test_func in tests:
        try:
            results[test_name] = test_func()
        except Exception as e:
            print(f"❌ {test_name} failed with exception: {str(e)}")
            results[test_name] = False
    
    # Print summary
    print("\n" + "=" * 60)
    print("📋 TEST SUMMARY")
    print("=" * 60)
    
    passed = 0
    total = len(results)
    
    for test_name, passed_test in results.items():
        status = "✅ PASS" if passed_test else "❌ FAIL"
        print(f"{test_name:20} {status}")
        if passed_test:
            passed += 1
    
    print(f"\nOverall: {passed}/{total} tests passed")
    
    if passed == total:
        print("🎉 All tests passed! Your model is ready for deployment.")
        return True
    else:
        print("⚠️  Some tests failed. Please check the errors above.")
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)