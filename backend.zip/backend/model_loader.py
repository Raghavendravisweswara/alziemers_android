"""
Model loading utilities for Keras 3 models
Safe loading with proper error handling and validation
"""

import tensorflow as tf
import keras
import os
import logging

logger = logging.getLogger(__name__)

class ModelLoader:
    """Handles safe loading of Keras models"""
    
    def __init__(self):
        self.model = None
        self.model_path = None
    
    def load_model(self, model_path):
        """
        Safely load a Keras model with proper error handling
        
        Args:
            model_path (str): Path to the .keras model file
            
        Returns:
            keras.Model: Loaded model
            
        Raises:
            Exception: If model loading fails
        """
        try:
            # Check if file exists
            if not os.path.exists(model_path):
                raise FileNotFoundError(f"Model file not found: {model_path}")
            
            # Check file size (basic validation)
            file_size = os.path.getsize(model_path)
            logger.info(f"Loading model from: {model_path}")
            logger.info(f"Model file size: {file_size / (1024*1024):.2f} MB")
            
            # Load the model
            # For Keras 3, use keras.models.load_model
            model = keras.models.load_model(model_path)
            
            # Validate the loaded model
            self._validate_model(model)
            
            self.model = model
            self.model_path = model_path
            
            logger.info("✅ Model loaded successfully")
            logger.info(f"Model input shape: {model.input_shape}")
            logger.info(f"Model output shape: {model.output_shape}")
            
            return model
            
        except Exception as e:
            logger.error(f"❌ Model loading failed: {str(e)}")
            raise Exception(f"Failed to load model: {str(e)}")
    
    def _validate_model(self, model):
        """
        Validate the loaded model
        
        Args:
            model: Loaded Keras model
            
        Raises:
            Exception: If validation fails
        """
        try:
            # Check if model has the expected structure
            if not hasattr(model, 'predict'):
                raise Exception("Model doesn't have predict method")
            
            # Check input/output shapes
            if not hasattr(model, 'input_shape') or not hasattr(model, 'output_shape'):
                logger.warning("Model doesn't have standard input/output shape attributes")
            
            # Try a dummy prediction to ensure model works
            dummy_input_shape = model.input_shape
            if dummy_input_shape[0] is None:  # Batch dimension
                test_shape = (1,) + dummy_input_shape[1:]
            else:
                test_shape = dummy_input_shape
            
            # Create dummy input
            import numpy as np
            dummy_input = np.random.random(test_shape).astype(np.float32)
            
            # Test prediction
            dummy_output = model.predict(dummy_input, verbose=0)
            logger.info(f"✅ Model validation successful - output shape: {dummy_output.shape}")
            
        except Exception as e:
            logger.error(f"❌ Model validation failed: {str(e)}")
            raise Exception(f"Model validation failed: {str(e)}")
    
    def get_model_summary(self):
        """Get model architecture summary"""
        if self.model is None:
            return "No model loaded"
        
        try:
            import io
            import sys
            
            # Capture model summary
            old_stdout = sys.stdout
            sys.stdout = buffer = io.StringIO()
            
            self.model.summary()
            
            sys.stdout = old_stdout
            summary = buffer.getvalue()
            
            return summary
        except Exception as e:
            return f"Failed to get model summary: {str(e)}"
    
    def convert_to_tflite(self, output_path=None):
        """
        Convert the loaded Keras model to TensorFlow Lite format
        for mobile deployment
        
        Args:
            output_path (str): Path to save the .tflite file
            
        Returns:
            str: Path to the saved .tflite file
        """
        if self.model is None:
            raise Exception("No model loaded")
        
        try:
            # Create converter
            converter = tf.lite.TFLiteConverter.from_keras_model(self.model)
            
            # Optional optimizations for mobile
            converter.optimizations = [tf.lite.Optimize.DEFAULT]
            
            # Convert the model
            tflite_model = converter.convert()
            
            # Save the model
            if output_path is None:
                output_path = "alzheimer_model_mobile.tflite"
            
            with open(output_path, 'wb') as f:
                f.write(tflite_model)
            
            logger.info(f"✅ TensorFlow Lite model saved: {output_path}")
            logger.info(f"TFLite model size: {len(tflite_model) / 1024:.2f} KB")
            
            return output_path
            
        except Exception as e:
            logger.error(f"❌ TFLite conversion failed: {str(e)}")
            raise Exception(f"TFLite conversion failed: {str(e)}")