"""
Model loading utilities for Keras 3 models
Safe loading with proper error handling and validation
"""

import os
import logging
import tensorflow as tf
import keras
import numpy as np
from tensorflow.keras import layers

logger = logging.getLogger(__name__)

class ModelLoader:
    """Handles safe loading of Keras models"""

    def __init__(self):
        self.model = None
        self.model_path = None

    def load_model(self, model_path):
        """Safely load a Keras model with custom transformer layer"""
        try:
            if not os.path.exists(model_path):
                raise FileNotFoundError(f"Model file not found: {model_path}")

            # Custom transformer encoder (from your notebook)
            def transformer_encoder(inputs, head_size=32, num_heads=2, ff_dim=64, dropout=0.1):
                x = layers.LayerNormalization(epsilon=1e-6)(inputs)
                x = layers.MultiHeadAttention(num_heads=num_heads, key_dim=head_size, dropout=dropout)(x, x)
                x = layers.Add()([x, inputs])
                x2 = layers.LayerNormalization(epsilon=1e-6)(x)
                x2 = layers.Dense(ff_dim, activation="relu")(x2)
                x2 = layers.Dropout(dropout)(x2)
                x2 = layers.Dense(inputs.shape[-1])(x2)
                return layers.Add()([x, x2])

            # Load model with custom_objects
            model = keras.models.load_model(
                model_path,
                custom_objects={"transformer_encoder": transformer_encoder}
            )

            # Validate the model
            self._validate_model(model)
            self.model = model
            self.model_path = model_path
            logger.info("✅ Model loaded successfully")
            return model

        except Exception as e:
            logger.error(f"❌ Model loading failed: {str(e)}")
            self.model = None
            raise e

    def _validate_model(self, model):
        """Validate the loaded model"""
        try:
            if not hasattr(model, 'predict'):
                raise Exception("Model doesn't have predict method")

            dummy_input_shape = model.input_shape
            if dummy_input_shape[0] is None:  # batch dimension
                test_shape = (1,) + dummy_input_shape[1:]
            else:
                test_shape = dummy_input_shape

            dummy_input = np.random.random(test_shape).astype(np.float32)
            dummy_output = model.predict(dummy_input, verbose=0)
            logger.info(f"✅ Model validation successful - output shape: {dummy_output.shape}")

        except Exception as e:
            logger.error(f"❌ Model validation failed: {str(e)}")
            raise Exception(f"Model validation failed: {str(e)}")

    def get_model_summary(self):
        """Get model architecture summary"""
        if self.model is None:
            return "No model loaded"
        try:
            import io
            import sys
            old_stdout = sys.stdout
            sys.stdout = buffer = io.StringIO()
            self.model.summary()
            sys.stdout = old_stdout
            return buffer.getvalue()
        except Exception as e:
            return f"Failed to get model summary: {str(e)}"

    def convert_to_tflite(self, output_path=None):
        """Convert the loaded Keras model to TensorFlow Lite format"""
        if self.model is None:
            raise Exception("No model loaded")
        try:
            converter = tf.lite.TFLiteConverter.from_keras_model(self.model)
            converter.optimizations = [tf.lite.Optimize.DEFAULT]
            tflite_model = converter.convert()
            if output_path is None:
                output_path = "alzheimer_model_mobile.tflite"
            with open(output_path, 'wb') as f:
                f.write(tflite_model)
            logger.info(f"✅ TensorFlow Lite model saved: {output_path}")
            logger.info(f"TFLite model size: {len(tflite_model)/1024:.2f} KB")
            return output_path
        except Exception as e:
            logger.error(f"❌ TFLite conversion failed: {str(e)}")
            raise Exception(f"TFLite conversion failed: {str(e)}")
