"""
Utility functions for image preprocessing and validation
"""

import numpy as np
from PIL import Image
import logging

logger = logging.getLogger(__name__)

def validate_image(image):
    """
    Validate uploaded image
    
    Args:
        image (PIL.Image): Input image
        
    Returns:
        bool: True if valid, False otherwise
    """
    try:
        # Check if image is valid
        if image is None:
            return False
        
        # Check image format
        if image.format not in ['JPEG', 'PNG', 'JPG', 'TIFF', 'BMP']:
            logger.warning(f"Unsupported image format: {image.format}")
            return False
        
        # Check image size (not too small, not too large)
        width, height = image.size
        
        if width < 50 or height < 50:
            logger.warning(f"Image too small: {width}x{height}")
            return False
        
        if width > 2000 or height > 2000:
            logger.warning(f"Image too large: {width}x{height}")
            return False
        
        # Check if image has valid channels
        if len(np.array(image).shape) < 2:
            logger.warning("Invalid image dimensions")
            return False
        
        logger.info(f"✅ Image validation passed: {width}x{height}, format: {image.format}")
        return True
        
    except Exception as e:
        logger.error(f"Image validation error: {str(e)}")
        return False

def preprocess_image(image, target_size=(224, 224)):
    """
    Preprocess image for model input
    Typical preprocessing for medical images:
    1. Resize to target size
    2. Convert to grayscale if needed
    3. Normalize pixel values
    4. Add batch dimension
    
    Args:
        image (PIL.Image): Input image
        target_size (tuple): Target size (width, height)
        
    Returns:
        np.ndarray: Preprocessed image ready for model
    """
    try:
        # Convert to RGB if needed (handles RGBA, etc.)
        if image.mode != 'RGB':
            image = image.convert('RGB')
        
        # Resize image to target size
        image_resized = image.resize(target_size, Image.Resampling.LANCZOS)
        
        # Convert to numpy array
        img_array = np.array(image_resized)
        
        # Normalize pixel values to [0, 1]
        img_array = img_array.astype(np.float32) / 255.0
        
        # Add batch dimension
        img_array = np.expand_dims(img_array, axis=0)
        
        logger.info(f"✅ Image preprocessed: shape {img_array.shape}")
        return img_array
        
    except Exception as e:
        logger.error(f"Image preprocessing error: {str(e)}")
        raise Exception(f"Failed to preprocess image: {str(e)}")

def postprocess_predictions(predictions, threshold=0.5):
    """
    Post-process model predictions
    
    Args:
        predictions (np.ndarray): Raw model predictions
        threshold (float): Confidence threshold
        
    Returns:
        dict: Processed predictions with metadata
    """
    try:
        # Get predicted class
        predicted_class = np.argmax(predictions, axis=1)[0]
        confidence = predictions[0][predicted_class]
        
        # Determine if prediction is confident enough
        is_confident = confidence > threshold
        
        result = {
            'predicted_class': int(predicted_class),
            'confidence': float(confidence),
            'is_confident': is_confident,
            'all_probabilities': predictions[0].tolist()
        }
        
        return result
        
    except Exception as e:
        logger.error(f"Postprocessing error: {str(e)}")
        raise Exception(f"Failed to postprocess predictions: {str(e)}")

def create_medical_report(prediction_result, patient_info=None):
    """
    Create a medical report from prediction results
    
    Args:
        prediction_result (dict): Prediction results
        patient_info (dict): Optional patient information
        
    Returns:
        dict: Formatted medical report
    """
    from datetime import datetime
    
    stages = ['Non-Demented', 'Very Mild Dementia', 'Mild Dementia', 'Moderate Dementia']
    
    report = {
        'report_id': f"ALZ_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
        'timestamp': datetime.now().isoformat(),
        'analysis': {
            'predicted_stage': stages[prediction_result['predicted_class']],
            'confidence_level': 'High' if prediction_result['confidence'] > 0.8 else 'Medium' if prediction_result['confidence'] > 0.6 else 'Low',
            'confidence_score': round(prediction_result['confidence'] * 100, 1),
            'stage_probabilities': {
                stage: round(prob * 100, 1) 
                for stage, prob in zip(stages, prediction_result['all_probabilities'])
            }
        },
        'recommendations': get_stage_recommendations(prediction_result['predicted_class']),
        'disclaimer': "This AI analysis is for research purposes only and should not be used as a substitute for professional medical diagnosis.",
        'model_info': {
            'model_type': 'Hybrid CNN+Transformer',
            'version': '1.0',
            'training_data': 'Medical MRI dataset'
        }
    }
    
    if patient_info:
        report['patient_info'] = patient_info
    
    return report

def get_stage_recommendations(stage_index):
    """Get recommendations based on predicted stage"""
    recommendations = {
        0: [  # Non-Demented
            "Continue regular cognitive health monitoring",
            "Maintain healthy lifestyle with regular exercise",
            "Follow a balanced diet rich in omega-3 fatty acids",
            "Engage in social activities and mental stimulation"
        ],
        1: [  # Very Mild Dementia
            "Consult with a neurologist for comprehensive evaluation",
            "Consider cognitive training exercises",
            "Implement daily routine structures",
            "Discuss medication options with healthcare provider"
        ],
        2: [  # Mild Dementia
            "Regular medical monitoring is essential",
            "Consider occupational therapy consultation",
            "Ensure safe home environment modifications",
            "Explore caregiver support resources"
        ],
        3: [  # Moderate Dementia
            "Intensive medical care and monitoring required",
            "Consider specialized dementia care facilities",
            "Implement comprehensive safety measures",
            "Seek professional caregiver assistance"
        ]
    }
    
    return recommendations.get(stage_index, ["Consult with healthcare professional"])