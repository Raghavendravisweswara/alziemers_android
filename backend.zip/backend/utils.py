"""
Utility functions for preprocessing and validating images
"""

import logging
import numpy as np
from tensorflow.keras.preprocessing.image import img_to_array
from PIL import Image

logger = logging.getLogger(__name__)

def validate_image(image):
    """
    Validate image format and size.
    Accept grayscale (L) and RGB images.
    """
    if image is None:
        return False

    # Accept grayscale (L) and RGB
    if image.mode not in ["L", "RGB"]:
        logger.warning(f"Unsupported image mode: {image.mode} — auto-converting to RGB")
        image = image.convert("RGB")

    # Minimum size check
    if image.width < 64 or image.height < 64:
        logger.warning(f"Image too small: {image.size}")
        return False

    return True


def preprocess_image(image, target_size=(224, 224)):
    """
    Resize, convert grayscale → RGB, and normalize for model input.
    Always returns a (1, target_size[0], target_size[1], 3) array.
    """
    try:
        # Convert grayscale to RGB if needed
        if image.mode == "L":
            image = image.convert("RGB")

        # Resize to model input size
        image = image.resize(target_size)

        # Convert to numpy array
        img_array = img_to_array(image)

        # Normalize [0,255] → [0,1]
        img_array = img_array.astype("float32") / 255.0

        # Add batch dimension
        img_array = np.expand_dims(img_array, axis=0)

        logger.info(f"✅ Image preprocessed: shape {img_array.shape}")
        return img_array
    except Exception as e:
        logger.error(f"❌ Preprocessing failed: {str(e)}")
        return None

