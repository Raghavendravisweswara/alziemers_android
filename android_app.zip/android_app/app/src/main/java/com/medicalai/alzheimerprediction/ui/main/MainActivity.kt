package com.medicalai.alzheimerprediction.ui.main

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.karumi.dexter.Dexter
import com.karumi.dexter.MultiplePermissionsReport
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.PermissionRequest
import com.karumi.dexter.listener.multi.MultiplePermissionsListener
import com.medicalai.alzheimerprediction.R
import com.medicalai.alzheimerprediction.databinding.ActivityMainBinding
import com.medicalai.alzheimerprediction.ui.history.HistoryActivity
import com.medicalai.alzheimerprediction.ui.result.PredictionResultActivity
import com.medicalai.alzheimerprediction.utils.ImageUtils
import kotlinx.coroutines.launch

/**
 * Main activity for the Alzheimer's Prediction app
 * Handles image capture/selection and initiates predictions
 */
class MainActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityMainBinding
    private lateinit var viewModel: MainViewModel
    
    private val cameraLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val imageBitmap = result.data?.extras?.get("data") as? Bitmap
            imageBitmap?.let { bitmap ->
                processCapturedImage(bitmap)
            }
        }
    }
    
    private val galleryLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        uri?.let {
            val bitmap = ImageUtils.getBitmapFromUri(this, it)
            bitmap?.let { processCapturedImage(it) }
        }
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        viewModel = ViewModelProvider(
            this,
            MainViewModelFactory(this)
        )[MainViewModel::class.java]
        
        setupUI()
        observeViewModel()
        checkApiHealth()
    }
    
    private fun setupUI() {
        binding.apply {
            btnCamera.setOnClickListener {
                checkPermissionsAndOpenCamera()
            }
            
            btnGallery.setOnClickListener {
                openGallery()
            }
            
            btnHistory.setOnClickListener {
                openHistory()
            }
            
            btnRefresh.setOnClickListener {
                checkApiHealth()
            }
        }
    }
    
    private fun observeViewModel() {
        viewModel.apiHealthStatus.observe(this) { isHealthy ->
            updateHealthIndicator(isHealthy)
        }
        
        viewModel.predictionResult.observe(this) { result ->
            result?.let {
                val intent = Intent(this, PredictionResultActivity::class.java).apply {
                    putExtra("prediction_result", it)
                }
                startActivity(intent)
                viewModel.clearPredictionResult()
            }
        }
        
        viewModel.loading.observe(this) { isLoading ->
            binding.progressBar.visibility = if (isLoading) {
                android.view.View.VISIBLE
            } else {
                android.view.View.GONE
            }
            
            binding.btnCamera.isEnabled = !isLoading
            binding.btnGallery.isEnabled = !isLoading
        }
        
        viewModel.error.observe(this) { errorMessage ->
            errorMessage?.let {
                showError(it)
                viewModel.clearError()
            }
        }
    }
    
    private fun checkPermissionsAndOpenCamera() {
        Dexter.withContext(this)
            .withPermissions(
                Manifest.permission.CAMERA,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            )
            .withListener(object : MultiplePermissionsListener {
                override fun onPermissionsChecked(report: MultiplePermissionsReport?) {
                    if (report?.areAllPermissionsGranted() == true) {
                        openCamera()
                    } else {
                        showPermissionError()
                    }
                }
                
                override fun onPermissionRationaleShouldBeShown(
                    permissions: MutableList<PermissionRequest>?,
                    token: PermissionToken?
                ) {
                    token?.continuePermissionRequest()
                }
            })
            .check()
    }
    
    private fun openCamera() {
        val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        cameraLauncher.launch(cameraIntent)
    }
    
    private fun openGallery() {
        galleryLauncher.launch("image/*")
    }
    
    private fun openHistory() {
        val intent = Intent(this, HistoryActivity::class.java)
        startActivity(intent)
    }
    
    private fun processCapturedImage(bitmap: Bitmap) {
        // Show image preview
        binding.ivPreview.setImageBitmap(bitmap)
        binding.cardImagePreview.visibility = android.view.View.VISIBLE
        
        // Show confirmation dialog
        MaterialAlertDialogBuilder(this)
            .setTitle("Process MRI Image")
            .setMessage("Do you want to analyze this MRI image for Alzheimer's prediction?")
            .setPositiveButton("Analyze") { _, _ ->
                analyzeImage(bitmap)
            }
            .setNegativeButton("Retake") { _, _ ->
                binding.cardImagePreview.visibility = android.view.View.GONE
            }
            .show()
    }
    
    private fun analyzeImage(bitmap: Bitmap) {
        lifecycleScope.launch {
            // Generate a demo user ID (in a real app, this would come from authentication)
            val userId = "user_${System.currentTimeMillis()}"
            
            viewModel.predictAlzheimer(bitmap, userId)
        }
    }
    
    private fun checkApiHealth() {
        lifecycleScope.launch {
            viewModel.checkApiHealth()
        }
    }
    
    private fun updateHealthIndicator(isHealthy: Boolean) {
        binding.apply {
            if (isHealthy) {
                tvApiStatus.text = "API Status: Connected ✅"
                tvApiStatus.setTextColor(ContextCompat.getColor(this@MainActivity, R.color.success_green))
                btnCamera.isEnabled = true
                btnGallery.isEnabled = true
            } else {
                tvApiStatus.text = "API Status: Disconnected ❌"
                tvApiStatus.setTextColor(ContextCompat.getColor(this@MainActivity, R.color.error_red))
                btnCamera.isEnabled = false
                btnGallery.isEnabled = false
            }
        }
    }
    
    private fun showError(message: String) {
        MaterialAlertDialogBuilder(this)
            .setTitle("Error")
            .setMessage(message)
            .setPositiveButton("OK", null)
            .show()
    }
    
    private fun showPermissionError() {
        MaterialAlertDialogBuilder(this)
            .setTitle("Permissions Required")
            .setMessage("Camera and storage permissions are required to capture and process MRI images.")
            .setPositiveButton("OK", null)
            .show()
    }
}