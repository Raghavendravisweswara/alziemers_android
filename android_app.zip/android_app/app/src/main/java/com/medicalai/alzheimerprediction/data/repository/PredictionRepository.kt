package com.medicalai.alzheimerprediction.data.repository

import android.content.Context
import android.graphics.Bitmap
import android.util.Base64
import com.medicalai.alzheimerprediction.data.api.ApiClient
import com.medicalai.alzheimerprediction.data.api.PredictionRequest
import com.medicalai.alzheimerprediction.data.api.PredictionResponse
import com.medicalai.alzheimerprediction.data.api.HistoryResponse
import com.medicalai.alzheimerprediction.utils.ImageUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream

/**
 * Repository for handling prediction-related API calls and data management
 */
class PredictionRepository(private val context: Context) {
    
    private val apiService = ApiClient.apiService
    
    /**
     * Upload image file and get Alzheimer's prediction
     */
    suspend fun predictWithImageFile(
        imageFile: File,
        userId: String? = null
    ): Result<PredictionResponse> = withContext(Dispatchers.IO) {
        try {
            val requestFile = imageFile.asRequestBody("image/jpeg".toMediaTypeOrNull())
            val imagePart = MultipartBody.Part.createFormData("image", imageFile.name, requestFile)
            
            val userIdPart = userId?.toRequestBody("text/plain".toMediaTypeOrNull())
            
            val response = apiService.predictAlzheimerStage(imagePart, userIdPart)
            
            if (response.isSuccessful) {
                response.body()?.let { prediction ->
                    Result.success(prediction)
                } ?: Result.failure(Exception("Empty response body"))
            } else {
                Result.failure(Exception("API Error: ${response.code()} ${response.message()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    /**
     * Convert bitmap to base64 and get prediction
     */
    suspend fun predictWithBitmap(
        bitmap: Bitmap,
        userId: String? = null
    ): Result<PredictionResponse> = withContext(Dispatchers.IO) {
        try {
            // Resize bitmap to model input size (224x224)
            val resizedBitmap = ImageUtils.resizeBitmap(bitmap, 224, 224)
            
            // Convert to base64
            val base64Image = bitmapToBase64(resizedBitmap)
            
            val request = PredictionRequest(
                image_data = base64Image,
                user_id = userId
            )
            
            val response = apiService.predictAlzheimerStageBase64(request)
            
            if (response.isSuccessful) {
                response.body()?.let { prediction ->
                    Result.success(prediction)
                } ?: Result.failure(Exception("Empty response body"))
            } else {
                Result.failure(Exception("API Error: ${response.code()} ${response.message()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    /**
     * Get user's prediction history from blockchain
     */
    suspend fun getUserHistory(userId: String): Result<HistoryResponse> = withContext(Dispatchers.IO) {
        try {
            val response = apiService.getUserHistory(userId)
            
            if (response.isSuccessful) {
                response.body()?.let { history ->
                    Result.success(history)
                } ?: Result.failure(Exception("Empty response body"))
            } else {
                Result.failure(Exception("API Error: ${response.code()} ${response.message()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    /**
     * Check API health status
     */
    suspend fun checkApiHealth(): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val response = apiService.checkHealth()
            
            if (response.isSuccessful) {
                val healthStatus = response.body()?.model_loaded ?: false
                Result.success(healthStatus)
            } else {
                Result.failure(Exception("API Error: ${response.code()} ${response.message()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    /**
     * Save image to local storage and return file
     */
    suspend fun saveImageToFile(bitmap: Bitmap, fileName: String): Result<File> = withContext(Dispatchers.IO) {
        try {
            val imagesDir = File(context.filesDir, "mri_images")
            if (!imagesDir.exists()) {
                imagesDir.mkdirs()
            }
            
            val imageFile = File(imagesDir, fileName)
            
            FileOutputStream(imageFile).use { fos ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 90, fos)
            }
            
            Result.success(imageFile)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    /**
     * Convert bitmap to base64 string
     */
    private fun bitmapToBase64(bitmap: Bitmap): String {
        val byteArrayOutputStream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 90, byteArrayOutputStream)
        val byteArray = byteArrayOutputStream.toByteArray()
        return Base64.encodeToString(byteArray, Base64.DEFAULT)
    }
}