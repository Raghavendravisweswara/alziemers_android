package com.medicalai.alzheimerprediction.data.api

import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Response
import retrofit2.http.*

/**
 * API service interface for communicating with the Flask backend
 */
interface ApiService {
    
    @GET("health")
    suspend fun checkHealth(): Response<HealthResponse>
    
    @Multipart
    @POST("predict")
    suspend fun predictAlzheimerStage(
        @Part image: MultipartBody.Part,
        @Part("user_id") userId: RequestBody? = null
    ): Response<PredictionResponse>
    
    @POST("predict")
    suspend fun predictAlzheimerStageBase64(
        @Body request: PredictionRequest
    ): Response<PredictionResponse>
    
    @GET("model/info")
    suspend fun getModelInfo(): Response<ModelInfoResponse>
    
    @GET("history/{userId}")
    suspend fun getUserHistory(
        @Path("userId") userId: String
    ): Response<HistoryResponse>
}

/**
 * Data classes for API requests and responses
 */
data class HealthResponse(
    val status: String,
    val model_loaded: Boolean,
    val timestamp: String
)

data class PredictionRequest(
    val image_data: String, // Base64 encoded image
    val user_id: String? = null
)

data class PredictionResponse(
    val predicted_stage: String,
    val predicted_stage_index: Int,
    val confidence_score: Double,
    val all_probabilities: Map<String, Double>,
    val image_hash: String,
    val timestamp: String,
    val model_version: String,
    val storage_url: String?,
    val blockchain_tx: String?
)

data class ModelInfoResponse(
    val model_type: String,
    val framework: String,
    val input_shape: List<Int>,
    val output_classes: List<String>,
    val total_params: String,
    val model_loaded: Boolean
)

data class HistoryResponse(
    val user_id: String,
    val predictions: List<HistoryItem>,
    val count: Int
)

data class HistoryItem(
    val tx_id: String,
    val timestamp: String,
    val image_hash: String,
    val prediction_data: PredictionResponse,
    val blockchain_type: String
)