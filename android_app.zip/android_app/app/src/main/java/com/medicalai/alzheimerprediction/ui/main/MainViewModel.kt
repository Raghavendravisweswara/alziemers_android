package com.medicalai.alzheimerprediction.ui.main

import android.content.Context
import android.graphics.Bitmap
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.medicalai.alzheimerprediction.data.api.PredictionResponse
import com.medicalai.alzheimerprediction.data.repository.PredictionRepository
import kotlinx.coroutines.launch

/**
 * ViewModel for MainActivity
 */
class MainViewModel(context: Context) : ViewModel() {
    
    private val repository = PredictionRepository(context)
    
    private val _loading = MutableLiveData<Boolean>()
    val loading: LiveData<Boolean> = _loading
    
    private val _error = MutableLiveData<String?>()
    val error: LiveData<String?> = _error
    
    private val _predictionResult = MutableLiveData<PredictionResponse?>()
    val predictionResult: LiveData<PredictionResponse?> = _predictionResult
    
    private val _apiHealthStatus = MutableLiveData<Boolean>()
    val apiHealthStatus: LiveData<Boolean> = _apiHealthStatus
    
    /**
     * Predict Alzheimer's stage from bitmap
     */
    fun predictAlzheimer(bitmap: Bitmap, userId: String) {
        viewModelScope.launch {
            _loading.value = true
            _error.value = null
            
            repository.predictWithBitmap(bitmap, userId)
                .onSuccess { prediction ->
                    _predictionResult.value = prediction
                }
                .onFailure { exception ->
                    _error.value = "Prediction failed: ${exception.message}"
                }
            
            _loading.value = false
        }
    }
    
    /**
     * Check API health status
     */
    fun checkApiHealth() {
        viewModelScope.launch {
            repository.checkApiHealth()
                .onSuccess { isHealthy ->
                    _apiHealthStatus.value = isHealthy
                }
                .onFailure { exception ->
                    _apiHealthStatus.value = false
                    _error.value = "API connection failed: ${exception.message}"
                }
        }
    }
    
    /**
     * Clear prediction result after navigation
     */
    fun clearPredictionResult() {
        _predictionResult.value = null
    }
    
    /**
     * Clear error message after displaying
     */
    fun clearError() {
        _error.value = null
    }
}