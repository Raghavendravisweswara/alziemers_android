package com.medicalai.alzheimerprediction.ui.result

import android.graphics.Color
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.github.mikephil.charting.data.PieData
import com.github.mikephil.charting.data.PieDataSet
import com.github.mikephil.charting.data.PieEntry
import com.medicalai.alzheimerprediction.R
import com.medicalai.alzheimerprediction.data.api.PredictionResponse
import com.medicalai.alzheimerprediction.databinding.ActivityPredictionResultBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Activity to display Alzheimer's prediction results with confidence chart
 */
class PredictionResultActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityPredictionResultBinding
    private lateinit var predictionResult: PredictionResponse
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPredictionResultBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        // Get prediction result from intent
        predictionResult = intent.getParcelableExtra("prediction_result")
            ?: return finish()
        
        setupUI()
        displayResults()
    }
    
    private fun setupUI() {
        binding.apply {
            toolbar.setNavigationOnClickListener {
                finish()
            }
            
            btnSaveReport.setOnClickListener {
                saveReport()
            }
            
            btnShareResult.setOnClickListener {
                shareResult()
            }
        }
    }
    
    private fun displayResults() {
        binding.apply {
            // Display main prediction
            tvPredictedStage.text = predictionResult.predicted_stage
            tvConfidenceScore.text = "${(predictionResult.confidence_score * 100).toInt()}%"
            
            // Set stage indicator color based on severity
            val stageColor = getStageColor(predictionResult.predicted_stage_index)
            cardStageIndicator.setCardBackgroundColor(stageColor)
            
            // Display confidence level text
            val confidenceText = when {
                predictionResult.confidence_score >= 0.8 -> "High Confidence"
                predictionResult.confidence_score >= 0.6 -> "Medium Confidence"
                else -> "Low Confidence"
            }
            tvConfidenceLevel.text = confidenceText
            
            // Display timestamp
            val dateFormat = SimpleDateFormat("MMM dd, yyyy 'at' HH:mm", Locale.getDefault())
            val date = Date() // In real app, parse predictionResult.timestamp
            tvTimestamp.text = "Analyzed on ${dateFormat.format(date)}"
            
            // Display model info
            tvModelVersion.text = "Model: ${predictionResult.model_version}"
            
            // Display blockchain info
            if (predictionResult.blockchain_tx != null) {
                tvBlockchainTx.text = "Blockchain TX: ${predictionResult.blockchain_tx?.take(16)}..."
                cardBlockchainInfo.visibility = android.view.View.VISIBLE
            }
            
            // Setup confidence chart
            setupConfidenceChart()
            
            // Display recommendations
            displayRecommendations()
        }
    }
    
    private fun setupConfidenceChart() {
        val entries = predictionResult.all_probabilities.map { (stage, probability) ->
            PieEntry((probability * 100).toFloat(), stage)
        }
        
        val dataSet = PieDataSet(entries, "Confidence Scores")
        dataSet.colors = listOf(
            ContextCompat.getColor(this, R.color.stage_0_color),
            ContextCompat.getColor(this, R.color.stage_1_color),
            ContextCompat.getColor(this, R.color.stage_2_color),
            ContextCompat.getColor(this, R.color.stage_3_color)
        )
        dataSet.valueTextSize = 12f
        dataSet.valueTextColor = Color.WHITE
        
        val pieData = PieData(dataSet)
        
        binding.chartConfidence.apply {
            data = pieData
            description.isEnabled = false
            legend.isEnabled = true
            setUsePercentValues(true)
            animateY(1000)
            invalidate()
        }
    }
    
    private fun displayRecommendations() {
        val recommendations = getRecommendationsForStage(predictionResult.predicted_stage_index)
        
        binding.apply {
            tvRecommendation1.text = "• ${recommendations.getOrNull(0) ?: "Consult with healthcare provider"}"
            tvRecommendation2.text = "• ${recommendations.getOrNull(1) ?: "Follow medical guidelines"}"
            tvRecommendation3.text = "• ${recommendations.getOrNull(2) ?: "Maintain regular checkups"}"
            
            // Show disclaimer
            tvDisclaimer.text = "⚠️ This AI analysis is for research purposes only and should not be used as a substitute for professional medical diagnosis."
        }
    }
    
    private fun getStageColor(stageIndex: Int): Int {
        return when (stageIndex) {
            0 -> ContextCompat.getColor(this, R.color.stage_0_color) // Green - Non-Demented
            1 -> ContextCompat.getColor(this, R.color.stage_1_color) // Yellow - Very Mild
            2 -> ContextCompat.getColor(this, R.color.stage_2_color) // Orange - Mild
            3 -> ContextCompat.getColor(this, R.color.stage_3_color) // Red - Moderate
            else -> ContextCompat.getColor(this, R.color.primary_color)
        }
    }
    
    private fun getRecommendationsForStage(stageIndex: Int): List<String> {
        return when (stageIndex) {
            0 -> listOf(
                "Continue regular cognitive health monitoring",
                "Maintain healthy lifestyle with regular exercise",
                "Follow a balanced diet rich in omega-3 fatty acids"
            )
            1 -> listOf(
                "Consult with a neurologist for comprehensive evaluation",
                "Consider cognitive training exercises",
                "Implement daily routine structures"
            )
            2 -> listOf(
                "Regular medical monitoring is essential",
                "Consider occupational therapy consultation",
                "Ensure safe home environment modifications"
            )
            3 -> listOf(
                "Intensive medical care and monitoring required",
                "Consider specialized dementia care facilities",
                "Seek professional caregiver assistance"
            )
            else -> listOf("Consult with healthcare professional")
        }
    }
    
    private fun saveReport() {
        // TODO: Implement saving report to local storage or cloud
        // This would typically save a PDF report or save to app's database
        android.widget.Toast.makeText(this, "Report saved to device", android.widget.Toast.LENGTH_SHORT).show()
    }
    
    private fun shareResult() {
        val shareText = """
            Alzheimer's Prediction Analysis
            
            Predicted Stage: ${predictionResult.predicted_stage}
            Confidence: ${(predictionResult.confidence_score * 100).toInt()}%
            
            Model: ${predictionResult.model_version}
            
            ⚠️ This analysis is for research purposes only.
            Please consult with a healthcare professional.
        """.trimIndent()
        
        val shareIntent = android.content.Intent().apply {
            action = android.content.Intent.ACTION_SEND
            putExtra(android.content.Intent.EXTRA_TEXT, shareText)
            type = "text/plain"
        }
        
        startActivity(android.content.Intent.createChooser(shareIntent, "Share Analysis Result"))
    }
}