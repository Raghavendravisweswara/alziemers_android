package com.medicalai.alzheimerprediction.utils

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.provider.MediaStore
import androidx.exifinterface.media.ExifInterface
import java.io.ByteArrayOutputStream
import java.io.InputStream

/**
 * Utility functions for image processing and manipulation
 */
object ImageUtils {
    
    /**
     * Resize bitmap to specified dimensions
     */
    fun resizeBitmap(bitmap: Bitmap, targetWidth: Int, targetHeight: Int): Bitmap {
        return Bitmap.createScaledBitmap(bitmap, targetWidth, targetHeight, true)
    }
    
    /**
     * Get bitmap from URI (from gallery)
     */
    fun getBitmapFromUri(context: Context, uri: Uri): Bitmap? {
        return try {
            val inputStream: InputStream? = context.contentResolver.openInputStream(uri)
            val bitmap = BitmapFactory.decodeStream(inputStream)
            inputStream?.close()
            
            // Rotate bitmap based on EXIF data
            val rotatedBitmap = rotateBitmapBasedOnExif(context, uri, bitmap)
            
            // Ensure bitmap is in RGB format
            if (rotatedBitmap.config != Bitmap.Config.ARGB_8888) {
                rotatedBitmap.copy(Bitmap.Config.ARGB_8888, false)
            } else {
                rotatedBitmap
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
    
    /**
     * Rotate bitmap based on EXIF orientation data
     */
    private fun rotateBitmapBasedOnExif(context: Context, uri: Uri, bitmap: Bitmap): Bitmap {
        return try {
            val inputStream = context.contentResolver.openInputStream(uri)
            val exif = ExifInterface(inputStream!!)
            val orientation = exif.getAttributeInt(
                ExifInterface.TAG_ORIENTATION,
                ExifInterface.ORIENTATION_NORMAL
            )
            inputStream.close()
            
            val matrix = Matrix()
            when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
                ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
                ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
                else -> return bitmap
            }
            
            Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
        } catch (e: Exception) {
            bitmap
        }
    }
    
    /**
     * Compress bitmap to JPEG with specified quality
     */
    fun compressBitmap(bitmap: Bitmap, quality: Int = 90): ByteArray {
        val outputStream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, quality, outputStream)
        return outputStream.toByteArray()
    }
    
    /**
     * Preprocess image for AI model input
     * - Resize to 224x224 (model input size)
     * - Normalize pixel values
     * - Ensure proper format
     */
    fun preprocessForModel(bitmap: Bitmap): Bitmap {
        // Resize to model input size
        val resized = resizeBitmap(bitmap, 224, 224)
        
        // Ensure RGB format
        return if (resized.config != Bitmap.Config.ARGB_8888) {
            resized.copy(Bitmap.Config.ARGB_8888, false)
        } else {
            resized
        }
    }
    
    /**
     * Validate if image is suitable for MRI analysis
     */
    fun validateMRIImage(bitmap: Bitmap): ValidationResult {
        val issues = mutableListOf<String>()
        
        // Check minimum size
        if (bitmap.width < 50 || bitmap.height < 50) {
            issues.add("Image too small (minimum 50x50 pixels)")
        }
        
        // Check maximum size
        if (bitmap.width > 2000 || bitmap.height > 2000) {
            issues.add("Image too large (maximum 2000x2000 pixels)")
        }
        
        // Check if image is valid
        if (bitmap.isRecycled) {
            issues.add("Image is corrupted or recycled")
        }
        
        // Check aspect ratio (should be roughly square for MRI)
        val aspectRatio = bitmap.width.toFloat() / bitmap.height.toFloat()
        if (aspectRatio < 0.5 || aspectRatio > 2.0) {
            issues.add("Unusual aspect ratio - MRI images should be roughly square")
        }
        
        return ValidationResult(
            isValid = issues.isEmpty(),
            issues = issues
        )
    }
    
    /**
     * Result of image validation
     */
    data class ValidationResult(
        val isValid: Boolean,
        val issues: List<String>
    )
    
    /**
     * Apply medical image preprocessing
     * This could include histogram equalization, noise reduction, etc.
     */
    fun applyMedicalPreprocessing(bitmap: Bitmap): Bitmap {
        // For now, just ensure proper format and size
        // In a real medical app, you might apply:
        // - Histogram equalization
        // - Gaussian blur for noise reduction
        // - Edge enhancement
        // - Contrast adjustment
        
        return preprocessForModel(bitmap)
    }
}